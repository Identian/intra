import os
import json
import boto3
from sys import stdout as sys_stdout, exc_info as sys_exc_info, argv as sys_argv
from logging import getLogger, StreamHandler, Formatter, INFO
from boto3 import client as bt3_client, resource as bt3_resource
import decimal
from decimal import Decimal

def setup_logging():
    PRECIA_LOG_FORMAT = (
        "%(asctime)s [%(levelname)s] [%(filename)s](%(funcName)s): %(message)s"
    )
    logger = getLogger()
    for handler in logger.handlers:
        logger.removeHandler(handler)
    precia_handler = StreamHandler(sys_stdout)
    precia_handler.setFormatter(Formatter(PRECIA_LOG_FORMAT))
    logger.addHandler(precia_handler)
    logger.setLevel(INFO)
    return logger


logger = setup_logging()


class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, decimal.Decimal):
            return float(str(o))
        return super(DecimalEncoder, self).default(o)

def get_data_request(json_request):
    collection_name = "dnb-rfli-isin-search-all-isines"
    dynamodb_client = bt3_client("dynamodb")
    try:
        logger.info("Comienza lectura en Dynamo")
        response = dynamodb_client.scan(**json_request)
        return convert_clean_json(response["Items"])
    except Exception as save_data_into_dynamo_exception:
        exception_line = sys_exc_info()[2].tb_lineno
        logger.error(
            "Error leyendo datos en dynamoDB para la tabla " + collection_name + "."
        )
        current_error = save_data_into_dynamo_exception
        logger.error(
            current_error.__class__.__name__
            + "["
            + str(exception_line)
            + "] "
            + str(current_error)
        )
        raise

def get_json(contract, request):
        collection_name = "dnb-rfli-isin-search-all-isines"
        try:
            flag = False
            if contract["issuer"] is not None:
                request["FilterExpression"] += "#business_name_f = :business_name_f"
                request["ExpressionAttributeNames"][
                    "#business_name_f"
                ] = "issuer_name"
                request["ExpressionAttributeValues"][":business_name_f"] = {
                    "S": f"{contract['issuer']}"
                }
                flag = True

            if contract["maturity_days"]["min"] is not None and flag is True:
                request[
                    "FilterExpression"
                ] += " And #maturity_days_min > :maturity_days_min"
                request["ExpressionAttributeNames"][
                    "#maturity_days_min"
                ] = "maturity_days"
                request["ExpressionAttributeValues"][":maturity_days_min"] = {
                    "N": f"{contract['maturity_days']['min']}"
                }
            elif contract["maturity_days"]["min"] is not None and flag is False:
                request["FilterExpression"] += "#maturity_days_min > :maturity_days_min"
                request["ExpressionAttributeNames"][
                    "#maturity_days_min"
                ] = "maturity_days"
                request["ExpressionAttributeValues"][":maturity_days_min"] = {
                    "N": f"{contract['maturity_days']['min']}"
                }
                flag = True

            if contract["maturity_days"]["max"] is not None and flag is True:
                request[
                    "FilterExpression"
                ] += " And #maturity_days_max < :maturity_days_max"
                request["ExpressionAttributeNames"][
                    "#maturity_days_max"
                ] = "maturity_days"
                request["ExpressionAttributeValues"][":maturity_days_max"] = {
                    "N": f"{contract['maturity_days']['max']}"
                }
            elif contract["maturity_days"]["max"] is not None and flag is False:
                request["FilterExpression"] += "#maturity_days_max < :maturity_days_max"
                request["ExpressionAttributeNames"][
                    "#maturity_days_max"
                ] = "maturity_days"
                request["ExpressionAttributeValues"][":maturity_days_max"] = {
                    "N": f"{contract['maturity_days']['max']}"
                }
                flag = True

            if contract["rate_type"] is not None and flag is True:
                request["FilterExpression"] += " and #rate_type_f = :rate_type_f"
                request["ExpressionAttributeNames"]["#rate_type_f"] = "rate_type"
                request["ExpressionAttributeValues"][":rate_type_f"] = {
                    "S": f"{contract['rate_type']}"
                }
            elif contract["rate_type"] is not None and flag is False:
                request["FilterExpression"] += "#rate_type_f = :rate_type_f"
                request["ExpressionAttributeNames"]["#rate_type_f"] = "rate_type"
                request["ExpressionAttributeValues"][":rate_type_f"] = {
                    "S": f"{contract['rate_type']}"
                }
                flag = True

            if contract["rating"] is not None and flag is True:
                request["FilterExpression"] += " and #real_rating_f = :real_rating_f"
                request["ExpressionAttributeNames"]["#real_rating_f"] = "real_rating"
                request["ExpressionAttributeValues"][":real_rating_f"] = {
                    "S": f"{contract['rating']}"
                }
            elif contract["rating"] is not None and flag is False:
                request["FilterExpression"] += "#real_rating_f = :real_rating_f"
                request["ExpressionAttributeNames"]["#real_rating_f"] = "real_rating"
                request["ExpressionAttributeValues"][":real_rating_f"] = {
                    "S": f"{contract['rating']}"
                }
                flag = True

            if contract["yield"]["min"] is not None and flag is True:
                request["FilterExpression"] += " and #yield_min > :yield_min"
                request["ExpressionAttributeNames"]["#yield_min"] = "yield"
                request["ExpressionAttributeValues"][":yield_min"] = {
                    "N": f"{contract['yield']['min']}"
                }
            elif contract["yield"]["min"] is not None and flag is False:
                request["FilterExpression"] += "#yield_min > :yield_min"
                request["yield_min"]["#yield_min"] = "yield"
                request["ExpressionAttributeValues"][":yield_min"] = {
                    "N": f"{contract['yield']['min']}"
                }
                flag = True

            if contract["yield"]["max"] is not None and flag is True:
                request["FilterExpression"] += " and #yield_max < :yield_max"
                request["ExpressionAttributeNames"]["#yield_max"] = "yield"
                request["ExpressionAttributeValues"][":yield_max"] = {
                    "N": f"{contract['yield']['max']}"
                }
            elif contract["yield"]["max"] is not None and flag is False:
                request["FilterExpression"] += "#yield_max < :yield_max"
                request["ExpressionAttributeNames"]["#yield_max"] = "yield"
                request["ExpressionAttributeValues"][":yield_max"] = {
                    "N": f"{contract['yield']['max']}"
                }
                flag = True

            if contract["currency"] is not None and flag is True:
                request[
                    "FilterExpression"
                ] += " and #currency_type_f = :currency_type_f"
                request["ExpressionAttributeNames"][
                    "#currency_type_f"
                ] = "currency_type"
                request["ExpressionAttributeValues"][":currency_type_f"] = {
                    "S": f"{contract['currency']}"
                }
            elif contract["currency"] is not None and flag is False:
                request["FilterExpression"] += "#currency_type_f = :currency_type_f"
                request["ExpressionAttributeNames"][
                    "#currency_type_f"
                ] = "currency_type"
                request["ExpressionAttributeValues"][":currency_type_f"] = {
                    "S": f"{contract['currency']}"
                }
                flag = True

            if request["FilterExpression"] == "":
                return {
                    "error": {
                        "code": 400,
                        "message": "La solicitud es incorrecta o defectuosa.",
                    }
                }
            print("Request json:", request)
            output_request = request
            return output_request
        except Exception as get_json_exception:
            exception_line = sys_exc_info()[2].tb_lineno
            logger.error(
                "Error leyendo datos en dynamoDB para la tabla " + collection_name + "."
            )
            current_error = get_json_exception
            logger.error(
                current_error.__class__.__name__
                + "["
                + str(exception_line)
                + "] "
                + str(current_error)
            )
            raise

def convert_clean_json(dictionary_list):
        clean_list = [
            {
                clave: float(valor["N"]) if "N" in valor else valor["S"]
                for clave, valor in diccionario.items()
            }
            for diccionario in dictionary_list
        ]
        return clean_list

def get_version():
    dynamodb_resource = bt3_resource("dynamodb")
    table1 = dynamodb_resource.Table("dnb-rfli-data-version-intra")
    version = table1.get_item(Key={"component": "isin-search"})
    return version["Item"]

def create_answer_request(list_item):
    try:
        version_item = get_version()
        answer = {
            "next_status": version_item["next_status"],
            "version": version_item["version"],
            "next_update":  version_item["next_update"],
            "data": list_item,
        }
        # print("Json de respuesta:", answer)
        return answer
    except Exception as create_string_query_exception:
        exception_line = sys_exc_info()[2].tb_lineno
        logger.error(
            "Error leyendo datos."
        )
        current_error = create_string_query_exception
        logger.error(
            current_error.__class__.__name__
            + "["
            + str(exception_line)
            + "] "
            + str(current_error)
        )
        raise 

def lambda_handler(event, context):
    request = {
        "TableName": "dnb-rfli-isin-search-all-isines",
        "FilterExpression": "",
        "ProjectionExpression": "#isin,#issuer_name,#maturity_days,#rate_type,#real_rating,#currency_type,#yield",
        "ExpressionAttributeNames": {
            "#isin": "isin",
            "#issuer_name": "issuer_name",
            "#maturity_days": "maturity_days",
            "#rate_type": "rate_type",
            "#real_rating": "real_rating",
            "#currency_type": "currency_type",
            "#yield": "yield",
        },
        "ExpressionAttributeValues": {},
    }
    try:
        json_consult = get_json(json.loads(event["body"]),request)
        datas = get_data_request(json_consult)
        element = create_answer_request(datas)
        return {"statusCode": 200, "body": json.dumps(element, cls=DecimalEncoder)}
    except Exception:
        logger.error(
            "Error iniciando el Glue para la inicializacion de la información de versiones - Aplicación intradia"
        )
        raise